package com.example.myapplication;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.IBinder;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Objects;

import static com.example.myapplication.App.CHANEL_ID;

public class Exemplo extends Service {

    @Override
    public void onCreate() {
        super.onCreate();
    }

    public static final int PRIMARY_FOREGROUND_NOTIFY_SERVICE_ID = 1001;

    String rs1;

    private MediaPlayer player;
    DatabaseReference ref;
    @SuppressLint("StaticFieldLeak")
    private static Context context;
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {




        String input = "Ativado";

        Intent notificationIntent = new Intent(this, frag1.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this,0,notificationIntent,0);

        Notification notification = new NotificationCompat.Builder(this, CHANEL_ID)
                .setContentTitle("MyHomeBit")
                .setContentText(input)
                .setSmallIcon(R.drawable.ic_launcher_background)
                .setContentIntent(pendingIntent)

                .build();







        ref = FirebaseDatabase.getInstance().getReference().child("");
        ref.addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {


                String ar = Objects.requireNonNull(dataSnapshot.child("Fumo").getValue()).toString();
                String movimento = Objects.requireNonNull(dataSnapshot.child("Movimento").getValue()).toString();
                String chama = Objects.requireNonNull(dataSnapshot.child("Alarme").getValue()).toString();




                switch (ar) {
                    case "1":

                        break;
                    case "0":

                        rs1 = "FUMO/GÀS DETETADO!";
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

                            String id = "_channel_01";
                            int importance = NotificationManager.IMPORTANCE_LOW;
                            NotificationChannel mChannel = new NotificationChannel(id, "notification", importance);
                            mChannel.enableLights(true);

                            Notification notification = new Notification.Builder(getApplicationContext(), id)
                                    .setSmallIcon(R.drawable.ic_baseline_warning_24)
                                    .setContentTitle("PERIGO!!")
                                    .setContentText("DETETADO FUMO!!")
                                    .build();

                            NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                            if (mNotificationManager != null) {
                                mNotificationManager.createNotificationChannel(mChannel);
                                mNotificationManager.notify(PRIMARY_FOREGROUND_NOTIFY_SERVICE_ID, notification);
                            }


                        }
                        break;

                }

                switch (movimento) {
                    case "0":

                        break;
                    case "1":

                        rs1 = "MOVIMENTO DETETADO!";
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

                            String id = "_channel_01";
                            int importance = NotificationManager.IMPORTANCE_LOW;
                            NotificationChannel mChannel = new NotificationChannel(id, "notification", importance);
                            mChannel.enableLights(true);

                            Notification notification = new Notification.Builder(getApplicationContext(), id)
                                    .setSmallIcon(R.drawable.ic_baseline_warning_24)
                                    .setContentTitle("PERIGO!!")
                                    .setContentText("DETETADO MOVIMENTO!!")
                                    .build();

                            NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                            if (mNotificationManager != null) {
                                mNotificationManager.createNotificationChannel(mChannel);
                                mNotificationManager.notify(PRIMARY_FOREGROUND_NOTIFY_SERVICE_ID, notification);
                            }


                        }

                        break;

                }

                switch (chama) {
                    case "0":

                        break;
                    case "1":

                        rs1 = "FOGO DETETADO!";
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

                            String id = "_channel_01";
                            int importance = NotificationManager.IMPORTANCE_LOW;
                            NotificationChannel mChannel = new NotificationChannel(id, "notification", importance);
                            mChannel.enableLights(true);

                            Notification notification = new Notification.Builder(getApplicationContext(), id)
                                    .setSmallIcon(R.drawable.ic_baseline_warning_24)
                                    .setContentTitle("PERIGO!!")
                                    .setContentText("DETETADO FOGO!!")
                                    .build();

                            NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                            if (mNotificationManager != null) {
                                mNotificationManager.createNotificationChannel(mChannel);
                                mNotificationManager.notify(PRIMARY_FOREGROUND_NOTIFY_SERVICE_ID, notification);
                            }


                        }
                        break;

                }




            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }

        });
        startForeground(1,notification);







        return START_NOT_STICKY;

            }




    @Override
    public void onDestroy() {
        super.onDestroy();

    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {


        return null;
    }
}
