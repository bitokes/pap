package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.TimePickerDialog;
import android.os.Build;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.ToggleButton;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Calendar;

public class auto extends AppCompatActivity {

TextView t1, t2;
Button btc, bts;



DatabaseReference ref;

int t1Hour,t1Minute,t2Hour,t2Minute,j1,j2,j3,j4;


    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auto);



        Button btc = (Button)findViewById(R.id.btc);
        Button bts = (Button)findViewById(R.id.bts);

        ToggleButton q1 = (ToggleButton)findViewById(R.id.q1);
        ToggleButton q2 = (ToggleButton)findViewById(R.id.q2);
        ToggleButton q3 = (ToggleButton)findViewById(R.id.q3);
        ToggleButton q4 = (ToggleButton)findViewById(R.id.q4);

        t1 = findViewById(R.id.t1);
        t2 = findViewById(R.id.t2);


        ref = FirebaseDatabase.getInstance().getReference().child("");
        ref.addValueEventListener(new ValueEventListener() {
            @SuppressLint("SetTextI18n")

            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {



                q1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                        if(isChecked == true){

                            j1 = 1;

                        }else  {

                            j1 = 0;
                        }





                    }
                });



               q2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                        if(isChecked == true){

                            j2 = 1;

                        }else  {

                            j2 = 0;
                        }





                    }
                });



                q3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                        if(isChecked == true){

                            j3 = 1;

                        }else  {

                            j3 = 0;
                        }





                    }
                });



                q4.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                        if(isChecked == true){

                            j4 = 1;

                        }else  {

                            j4 = 0;
                        }





                    }
                });



                bts.setOnClickListener(new android.view.View.OnClickListener() {
                    @Override


                    public void onClick(View v) {




                        if(j1 == 1){
                            ref.child("auto").child("Luz1").setValue("1");
                        }else {
                            ref.child("auto").child("Luz1").setValue("0");
                        }


                        if(j2 == 1){
                            ref.child("auto").child("Luz2").setValue("1");
                        }else {
                            ref.child("auto").child("Luz2").setValue("0");
                        }


                        if(j3 == 1){
                            ref.child("auto").child("Luz3").setValue("1");
                        }else {
                            ref.child("auto").child("Luz3").setValue("0");
                        }


                        if(j4 == 1){
                            ref.child("auto").child("Luz4").setValue("1");
                        }else {
                            ref.child("auto").child("Luz4").setValue("0");
                        }


                        ref.child("auto").child("hora ini").setValue(t1Hour);
                        ref.child("auto").child("min ini").setValue(t1Minute);
                        ref.child("auto").child("hora fin").setValue(t2Hour);
                        ref.child("auto").child("min fin").setValue(t2Minute);




                    }

                });

                btc.setOnClickListener(new android.view.View.OnClickListener() {
                    @Override


                    public void onClick(View v) {



                        ref.child("auto").child("Luz1").setValue("0");
                        ref.child("auto").child("Luz2").setValue("0");
                        ref.child("auto").child("Luz3").setValue("0");
                        ref.child("auto").child("Luz4").setValue("0");
                        ref.child("auto").child("hora ini").setValue(0);
                        ref.child("auto").child("min ini").setValue(0);
                        ref.child("auto").child("hora fin").setValue(0);
                        ref.child("auto").child("min fin").setValue(0);
                        q1.setChecked(false);
                        q2.setChecked(false);
                        q3.setChecked(false);
                        q4.setChecked(false);




                    }

                });







                t1.setOnClickListener(new View.OnClickListener(){


                    @Override
                    public void onClick(View v) {

                        TimePickerDialog timePickerDialog = new TimePickerDialog(
                                auto.this,

                                new TimePickerDialog.OnTimeSetListener() {
                                    @Override
                                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                                        t1Hour = hourOfDay;
                                        t1Minute = minute;

                                        Calendar calender = Calendar.getInstance();

                                        calender.set( 0, 0,  0,t1Hour  ,t1Minute );

                                        t1.setText(DateFormat.format( "hh:mm aa", calender));

                                    }
                                },12,0,false
                        );

                        timePickerDialog.updateTime(t1Hour,t1Minute);

                        timePickerDialog.show();

                    }
                });

                t2.setOnClickListener(new View.OnClickListener(){


                    @Override
                    public void onClick(View v) {

                        TimePickerDialog timePickerDialog = new TimePickerDialog(
                                auto.this,

                                new TimePickerDialog.OnTimeSetListener() {
                                    @Override
                                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                                        t2Hour = hourOfDay;
                                        t2Minute = minute;

                                        Calendar calender = Calendar.getInstance();

                                        calender.set( 0, 0,  0,t2Hour  ,t2Minute );

                                        t2.setText(DateFormat.format( "hh:mm aa", calender));

                                    }
                                },12,0,false
                        );

                        timePickerDialog.updateTime(t2Hour,t2Minute);

                        timePickerDialog.show();

                    }
                });
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {








            }
        });








    }
}