package com.example.myapplication;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Objects;

public class frag1 extends Fragment  {



    TextView a;
    TextView b;
    TextView c;
    TextView d;
    TextView e;
    Switch f;

    DatabaseReference ref;




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        View v = inflater.inflate(R.layout.fragment_frag1, container, false);




        a = (TextView) v.findViewById(R.id.txHum);
        b = (TextView) v.findViewById(R.id.tp);
        c = (TextView) v.findViewById(R.id.qa);
        d = (TextView) v.findViewById(R.id.tm);
        e = (TextView) v.findViewById(R.id.cha);
        f = (Switch) v.findViewById(R.id.arm);






        ref = FirebaseDatabase.getInstance().getReference().child("");
        ref.addValueEventListener(new ValueEventListener() {

            @SuppressLint("SetTextI18n")
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {


                String humidity = Objects.requireNonNull(dataSnapshot.child("Humidade").getValue()).toString();
                String temperature = Objects.requireNonNull(dataSnapshot.child("Temperatura").getValue()).toString();
                String ar = Objects.requireNonNull(dataSnapshot.child("Fumo").getValue()).toString();
                String movimento = Objects.requireNonNull(dataSnapshot.child("Movimento").getValue()).toString();
                String chama = Objects.requireNonNull(dataSnapshot.child("Alarme").getValue()).toString();



                a.setText(humidity+"%");
                b.setText(temperature+"º");

                String data4 = Objects.requireNonNull(dataSnapshot.child("sw").getValue()).toString();

                switch (data4) {
                    case "1":
                        f.setChecked(true);
                        break;
                    case "0":
                        f.setChecked(false);

                }


                f.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                        if (isChecked){


                            String input = "raw";

                            Intent serviceIntent = new Intent(getContext(), Exemplo.class);
                            serviceIntent.putExtra("inputExtra", input);

                            getActivity().startService(serviceIntent);
                            getActivity().startService(new Intent(getContext(), Exemplo.class));

                            ref.child("").child("sw").setValue("1");


                        }else {
                            String input = "raw";

                            Intent serviceIntent = new Intent(getContext(), Exemplo.class);
                            serviceIntent.putExtra("inputExtra", input);

                            getActivity().stopService(serviceIntent);
                            getActivity().stopService(new Intent(getContext(), Exemplo.class));

                            ref.child("").child("sw").setValue("0");


                        }

                    }
                });


                switch (ar) {
                    case "1":
                        c.setText("OK");
                        break;
                    case "0":
                        c.setText("PERIGO!");


                        break;

                }

                switch (movimento) {
                   case "0":
                       d.setText("OK");
                       break;
                    case "1":
                        d.setText("PERIGO!");


                       break;

                }

                switch (chama) {
                    case "0":
                        e.setText("OK");
                        break;
                    case "1":
                        e.setText("PERIGO!");

                        break;

                }




            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }

        });


        return v;
    }




}
