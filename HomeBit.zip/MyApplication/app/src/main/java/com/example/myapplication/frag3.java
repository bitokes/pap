package com.example.myapplication;

import android.annotation.SuppressLint;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.TimePicker;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Calendar;
import java.util.Objects;


public class frag3 extends Fragment {

    ImageView t1, t2;
    int t1Hour,t1Minute,t2Hour,t2Minute,j1,j2,j3,j4,j5,j6;


    TextView eet1,eet2,eet3,eet4,eet5,eet6 ;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {





        View f = inflater.inflate(R.layout.fragment_frag3, container, false);
        t1 = f.findViewById(R.id.hi);
        t2 = f.findViewById(R.id.hf);

        DatabaseReference ref;



        Button btc = (Button)f.findViewById(R.id.btc);
        Button bts = (Button)f.findViewById(R.id.bti);
        eet1 = (TextView) f.findViewById(R.id.et1);
        eet2 = (TextView) f.findViewById(R.id.et2);
        eet3 = (TextView) f.findViewById(R.id.et3);
        eet4 = (TextView) f.findViewById(R.id.et4);
        eet5 = (TextView) f.findViewById(R.id.et5);
        eet6 = (TextView) f.findViewById(R.id.et6);

        Switch q1 = (Switch) f.findViewById(R.id.q1);
        Switch q2 = (Switch) f.findViewById(R.id.q2);
        Switch q3 = (Switch) f.findViewById(R.id.q3);
        Switch q4 = (Switch) f.findViewById(R.id.q4);
        Switch q5 = (Switch) f.findViewById(R.id.q5);
        Switch q6 = (Switch) f.findViewById(R.id.q6);


        ref = FirebaseDatabase.getInstance().getReference().child("");
        ref.addValueEventListener(new ValueEventListener() {
            @SuppressLint("SetTextI18n")

            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {



                String ds = Objects.requireNonNull(dataSnapshot.child("et1").getValue()).toString();

                eet1.setText(ds);

                String d2 = Objects.requireNonNull(dataSnapshot.child("et2").getValue()).toString();

                eet2.setText(d2);

                String d3 = Objects.requireNonNull(dataSnapshot.child("et3").getValue()).toString();

                eet3.setText(d3);

                String d4 = Objects.requireNonNull(dataSnapshot.child("et4").getValue()).toString();

                eet4.setText(d4);

                String d5 = Objects.requireNonNull(dataSnapshot.child("et5").getValue()).toString();

                eet5.setText(d5);

                String d6 = Objects.requireNonNull(dataSnapshot.child("et6").getValue()).toString();

                eet6.setText(d6);



                q1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                        if(isChecked == true){

                            j1 = 1;

                        }else  {

                            j1 = 0;
                        }





                    }
                });



                q2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                        if(isChecked == true){

                            j2 = 1;

                        }else  {

                            j2 = 0;
                        }





                    }
                });



                q3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                        if(isChecked == true){

                            j3 = 1;

                        }else  {

                            j3 = 0;
                        }





                    }
                });



                q4.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                        if(isChecked == true){

                            j4 = 1;

                        }else  {

                            j4 = 0;
                        }





                    }
                });

                q5.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                        if(isChecked == true){

                            j5 = 1;

                        }else  {

                            j5 = 0;
                        }





                    }
                });

                q6.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                        if(isChecked == true){

                            j6 = 1;

                        }else  {

                            j6 = 0;
                        }





                    }
                });



                bts.setOnClickListener(new android.view.View.OnClickListener() {
                    @Override


                    public void onClick(View v) {




                        if(j1 == 1){
                            ref.child("auto").child("Luz1").setValue("1");
                        }else {
                            ref.child("auto").child("Luz1").setValue("0");
                        }


                        if(j2 == 1){
                            ref.child("auto").child("Luz2").setValue("1");
                        }else {
                            ref.child("auto").child("Luz2").setValue("0");
                        }


                        if(j3 == 1){
                            ref.child("auto").child("Luz3").setValue("1");
                        }else {
                            ref.child("auto").child("Luz3").setValue("0");
                        }


                        if(j4 == 1){
                            ref.child("auto").child("Luz4").setValue("1");
                        }else {
                            ref.child("auto").child("Luz4").setValue("0");
                        }

                        if(j5 == 1){
                            ref.child("auto").child("Luz5").setValue("1");
                        }else {
                            ref.child("auto").child("Luz5").setValue("0");
                        }

                        if(j6 == 1){
                            ref.child("auto").child("Luz6").setValue("1");
                        }else {
                            ref.child("auto").child("Luz6").setValue("0");
                        }


                        ref.child("auto").child("confi").setValue("1");
                        ref.child("auto").child("hora ini").setValue(t1Hour);
                        ref.child("auto").child("min ini").setValue(t1Minute);
                        ref.child("auto").child("hora fin").setValue(t2Hour);
                        ref.child("auto").child("min fin").setValue(t2Minute);




                    }

                });

                btc.setOnClickListener(new android.view.View.OnClickListener() {
                    @Override


                    public void onClick(View v) {


                        ref.child("auto").child("confi").setValue("0");
                        ref.child("auto").child("Luz1").setValue("0");
                        ref.child("auto").child("Luz2").setValue("0");
                        ref.child("auto").child("Luz3").setValue("0");
                        ref.child("auto").child("Luz4").setValue("0");
                        ref.child("auto").child("Luz5").setValue("0");
                        ref.child("auto").child("Luz6").setValue("0");
                        ref.child("auto").child("hora ini").setValue(0);
                        ref.child("auto").child("min ini").setValue(0);
                        ref.child("auto").child("hora fin").setValue(0);
                        ref.child("auto").child("min fin").setValue(0);
                        q1.setChecked(false);
                        q2.setChecked(false);
                        q3.setChecked(false);
                        q4.setChecked(false);
                        q5.setChecked(false);
                        q6.setChecked(false);




                    }

                });







                t1.setOnClickListener(new View.OnClickListener(){


                    @Override
                    public void onClick(View v) {

                        TimePickerDialog timePickerDialog = new TimePickerDialog(
                                getContext(),

                                new TimePickerDialog.OnTimeSetListener() {
                                    @Override
                                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                                        t1Hour = hourOfDay;
                                        t1Minute = minute;

                                        Calendar calender = Calendar.getInstance();

                                        calender.set( 0, 0,  0,t1Hour  ,t1Minute );


                                    }
                                },12,0,false
                        );

                        timePickerDialog.updateTime(t1Hour,t1Minute);

                        timePickerDialog.show();

                    }
                });

                t2.setOnClickListener(new View.OnClickListener(){


                    @Override
                    public void onClick(View v) {

                        TimePickerDialog timePickerDialog = new TimePickerDialog(
                                getContext(),

                                new TimePickerDialog.OnTimeSetListener() {
                                    @Override
                                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                                        t2Hour = hourOfDay;
                                        t2Minute = minute;

                                        Calendar calender = Calendar.getInstance();

                                        calender.set( 0, 0,  0,t2Hour  ,t2Minute );



                                    }
                                },12,0,false
                        );

                        timePickerDialog.updateTime(t2Hour,t2Minute);

                        timePickerDialog.show();

                    }
                });
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {








            }
        });







        return f;
    }  }