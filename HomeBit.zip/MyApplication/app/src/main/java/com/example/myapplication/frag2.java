package com.example.myapplication;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Objects;

public class frag2 extends Fragment {

    Switch a, b, c, d, e, f;
    String es1,es2,es3,es4,es5,es6;
    DatabaseReference ref;
    TextView eet1,eet2,eet3,eet4,eet5,eet6 ;


@SuppressLint("SetTextI18n")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_frag2, container, false);


        a =  v.findViewById(R.id.txHum);
        b =  v.findViewById(R.id.tp);
        c =  v.findViewById(R.id.ch);
        d =  v.findViewById(R.id.qa);
        e =  v.findViewById(R.id.arm);
        f = (Switch) v.findViewById(R.id.mv);
        eet1 = (TextView) v.findViewById(R.id.et1);
        eet2 = (TextView) v.findViewById(R.id.et2);
        eet3 = (TextView) v.findViewById(R.id.et3);
        eet4 = (TextView) v.findViewById(R.id.et4);
        eet5 = (TextView) v.findViewById(R.id.et5);
        eet6 = (TextView) v.findViewById(R.id.et6);





        ref = FirebaseDatabase.getInstance().getReference().child("");
        ref.addValueEventListener(new ValueEventListener() {




            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {









                eet1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        AlertDialog.Builder mydialog = new AlertDialog.Builder(getContext());
                        mydialog.setTitle("Mudar nome da divisão");

                        final EditText Weightinput = new EditText(getContext());
                        Weightinput.setInputType(InputType.TYPE_CLASS_TEXT);
                        mydialog.setView(Weightinput);

                        mydialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                es1=Weightinput.getText().toString();
                                ref.child("").child("et1").setValue(es1);
                            }
                        });

                        mydialog.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        });
                        mydialog.show();


                    }
                });

                eet2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        AlertDialog.Builder mydialog = new AlertDialog.Builder(getContext());
                        mydialog.setTitle("Mudar nome da divisão");

                        final EditText Weightinput = new EditText(getContext());
                        Weightinput.setInputType(InputType.TYPE_CLASS_TEXT);
                        mydialog.setView(Weightinput);

                        mydialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                es2=Weightinput.getText().toString();
                                ref.child("").child("et2").setValue(es2);
                            }
                        });

                        mydialog.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        });
                        mydialog.show();


                    }
                });

                eet3.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        AlertDialog.Builder mydialog = new AlertDialog.Builder(getContext());
                        mydialog.setTitle("Mudar nome da divisão");

                        final EditText Weightinput = new EditText(getContext());
                        Weightinput.setInputType(InputType.TYPE_CLASS_TEXT);
                        mydialog.setView(Weightinput);

                        mydialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                es3=Weightinput.getText().toString();
                                ref.child("").child("et3").setValue(es3);
                            }
                        });

                        mydialog.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        });
                        mydialog.show();


                    }
                });

                eet4.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        AlertDialog.Builder mydialog = new AlertDialog.Builder(getContext());
                        mydialog.setTitle("Mudar nome da divisão");

                        final EditText Weightinput = new EditText(getContext());
                        Weightinput.setInputType(InputType.TYPE_CLASS_TEXT);
                        mydialog.setView(Weightinput);

                        mydialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                es4=Weightinput.getText().toString();
                                ref.child("").child("et4").setValue(es4);
                            }
                        });

                        mydialog.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        });
                        mydialog.show();


                    }
                });

                eet5.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        AlertDialog.Builder mydialog = new AlertDialog.Builder(getContext());
                        mydialog.setTitle("Mudar nome da divisão");

                        final EditText Weightinput = new EditText(getContext());
                        Weightinput.setInputType(InputType.TYPE_CLASS_TEXT);
                        mydialog.setView(Weightinput);

                        mydialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                es5=Weightinput.getText().toString();
                                ref.child("").child("et5").setValue(es5);
                            }
                        });

                        mydialog.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        });
                        mydialog.show();


                    }
                });

                eet6.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        AlertDialog.Builder mydialog = new AlertDialog.Builder(getContext());
                        mydialog.setTitle("Mudar nome da divisão");

                        final EditText Weightinput = new EditText(getContext());
                        Weightinput.setInputType(InputType.TYPE_CLASS_TEXT);
                        mydialog.setView(Weightinput);

                        mydialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                es6=Weightinput.getText().toString();
                                ref.child("").child("et6").setValue(es6);
                            }
                        });

                        mydialog.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        });
                        mydialog.show();


                    }
                });




                String ds = Objects.requireNonNull(dataSnapshot.child("et1").getValue()).toString();

                eet1.setText(ds);

                String d2 = Objects.requireNonNull(dataSnapshot.child("et2").getValue()).toString();

                eet2.setText(d2);

                String d3 = Objects.requireNonNull(dataSnapshot.child("et3").getValue()).toString();

                eet3.setText(d3);

                String d4 = Objects.requireNonNull(dataSnapshot.child("et4").getValue()).toString();

                eet4.setText(d4);

                String d5 = Objects.requireNonNull(dataSnapshot.child("et5").getValue()).toString();

                eet5.setText(d5);

                String d6 = Objects.requireNonNull(dataSnapshot.child("et6").getValue()).toString();

                eet6.setText(d6);

                String data1 = Objects.requireNonNull(dataSnapshot.child("luz1").getValue()).toString();

                switch (data1) {
                    case "1":
                        a.setChecked(true);
                        break;
                    case "0":
                        a.setChecked(false);



                }

                String data2 = Objects.requireNonNull(dataSnapshot.child("luz2").getValue()).toString();

                switch (data2) {
                    case "1":
                        b.setChecked(true);
                        break;
                    case "0":
                        b.setChecked(false);
                }


                String data3 = Objects.requireNonNull(dataSnapshot.child("luz3").getValue()).toString();

                switch (data3) {
                    case "1":
                        c.setChecked(true);
                        break;
                    case "0":
                        c.setChecked(false);

                }


                String data4 = Objects.requireNonNull(dataSnapshot.child("luz4").getValue()).toString();

                switch (data4) {
                    case "1":
                        d.setChecked(true);
                        break;
                    case "0":
                        d.setChecked(false);

                }

                String data5 = Objects.requireNonNull(dataSnapshot.child("luz5").getValue()).toString();

                switch (data5) {
                    case "1":
                        e.setChecked(true);
                        break;
                    case "0":
                        e.setChecked(false);

                }

                String data6 = Objects.requireNonNull(dataSnapshot.child("luz6").getValue()).toString();

                switch (data6) {
                    case "1":
                        f.setChecked(true);
                        break;
                    case "0":
                        f.setChecked(false);

                }


                        a.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                        if (isChecked){


                            ref.child("").child("luz1").setValue("1");





                        }else {

                            ref.child("").child("luz1").setValue("0");



                        }

                    }
                });

                b.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                        if (isChecked){


                            ref.child("").child("luz2").setValue("1");



                        }else {

                            ref.child("").child("luz2").setValue("0");



                        }

                    }
                });

                c.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                        if (isChecked){


                            ref.child("").child("luz3").setValue("1");





                        }else {

                            ref.child("").child("luz3").setValue("0");





                            }

                        }


                });

                d.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                        if (isChecked){


                            ref.child("").child("luz4").setValue("1");



                        }else {

                            ref.child("").child("luz4").setValue("0");


                        }

                    }
                });

                e.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                        if (isChecked){


                            ref.child("").child("luz5").setValue("1");



                        }else {

                            ref.child("").child("luz5").setValue("0");


                        }

                    }
                });

                f.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                        if (isChecked){


                            ref.child("").child("luz6").setValue("1");



                        }else {

                            ref.child("").child("luz6").setValue("0");


                        }

                    }
                });


            }


            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        return v;
    }


}

